package com.example.app_recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView1);
        List<Person> personList = new ArrayList<>();

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        //Adapter
        PersonAdapter adapter = new PersonAdapter(personList);
        recyclerView.setAdapter(adapter);

        // 데이터를 강제적으로 주입시킴
        for(int i=0; i<20; i++){
            adapter.addItem(new Person("홍길동"+i, "010-1111-2222"));
        }
    }
}